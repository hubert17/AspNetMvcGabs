﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyAspNetMvcApp.Models.Lessons
{
    public class Grade
    {
        public string Subject { get; set; }
        public double FinalGrade { get; set; }
    }
}