﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Gabs.Helpers
{
    public class SMSUtil
    {
    }
}